sap.ui.define(['sap/suite/ui/generic/template/lib/AppComponent'], function(AppComponent) {
    return AppComponent.extend('falp.his.falp_his_parametros.Component', {
        metadata: {
            manifest: 'json'
        }
    });
});
